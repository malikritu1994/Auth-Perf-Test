package com.anaplan.authperftest;

import com.anaplan.perftesttools.CSVParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import us.abstracta.jmeter.javadsl.core.DslTestPlan;
import us.abstracta.jmeter.javadsl.core.threadgroups.DslThreadGroup;
import us.abstracta.jmeter.javadsl.http.DslHttpSampler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.anaplan.authperftest.AuthLookup.GetJsonString;
import static com.anaplan.authperftest.AuthLookup.jsonLookup;
import static us.abstracta.jmeter.javadsl.JmeterDsl.*;


public class AuthService {

    static final int countThreshold = 100;
    static List<DslThreadGroup> putThreadGroups = new ArrayList<DslThreadGroup>();
    static List<DslThreadGroup> getThreadGroups = new ArrayList<DslThreadGroup>();
    static List<DslThreadGroup> postThreadGroups = new ArrayList<DslThreadGroup>();
    static Map commands;


    public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        commands = jsonLookup();

        CSVParser csvParser = new CSVParser(AuthService.class.getClassLoader().getResourceAsStream("AuthLoadProfile_Prod2Months-2023-03-01.csv"), true);
        csvParser.defineColumn("PATH", 2);
        csvParser.defineColumn("METHOD", 1);
        csvParser.defineColumn("COUNT", 3);
        String path;
        do {
            path = csvParser.get("PATH");
            String method = csvParser.get("METHOD");
            int count = Integer.parseInt(csvParser.get("COUNT"));
            if (count >= countThreshold) {
                if (method.equalsIgnoreCase("PUT")) {
                    putThreadGroups.add(putThreadGroups(path, count));
                }
                if (method.equalsIgnoreCase("GET")) {
                    getThreadGroups.add(getThreadGroups(method, path, count));
                }
                if (method.equalsIgnoreCase("POST")) {
                    postThreadGroups.add(postThreadGroups(path, count));
                }
            }


            csvParser.incrementRowIndex();
        } while (csvParser.hasRow());


        DslTestPlan tp = createTestPlan();
        putThreadGroups.forEach((tg) -> tp.children(tg));
        getThreadGroups.forEach((tg) -> tp.children(tg));
        postThreadGroups.forEach((tg) -> tp.children(tg));

        tp.showInGui();

    }


    public static DslThreadGroup putThreadGroups(String path, int count) throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException {


        String threadCount = tpm(count);

        return threadGroup("PUT " + path.replace("$", ""))
                .rampToAndHold(threadCount, "10", "3590")
                .children(onceOnlyController(
                        AuthTokenSampler()
                        ),
                        runtimeController("600",
                                addEndpointSampler("PUT", path, count)
                        ),
                        AuthRefreshSampler()
                );

    }

    public static DslThreadGroup postThreadGroups(String path, int count) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        String threadCount = tpm(count);
        AuthLookup authLookup = new AuthLookup();

        DslThreadGroup dslThreadGroup = authLookup.GetThreadGroup(path);

        if (dslThreadGroup != null) {

            return dslThreadGroup;
        } else {

            return threadGroup("POST " + path.replace("$", ""))
                    .rampToAndHold(threadCount, "10", "3590")
                    .children
                            (onceOnlyController(
                                    AuthTokenSampler()
                                    ),
                                    runtimeController("600",
                                            addEndpointSampler("POST", path, count)
                                    ),
                                    AuthRefreshSampler()
                            );
        }
    }

    static String SetPostBody(Map commands, String path) throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        return GetJsonString(commands, path);
    }


    public static DslHttpSampler addEndpointSampler(String method, String path, int count) throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        return httpSampler(method + " " + path.replace("$", ""), path)
                .host("${Domain_Auth}")
                .protocol("${protocol}")
                .method(method).
                        children(httpHeaders()
                                        .header("Content-Type", "application/json")
                                        .header("Accept-Encoding", "gzip")
                                        .header("Authorization", "AnaplanAuthToken ${tokenValue}")
                                        .header("User-Agent", "AuthPerfTest_" + method + path.replace("$", "").replace(" ", "")),
                                        throughputTimer(count / 60))
                .body(SetPostBody(commands, path));

    }

    public static DslThreadGroup getThreadGroups(String method, String path, int count) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {


        String threadCount = tpm(count);
        AuthLookup authLookup = new AuthLookup();

        DslThreadGroup dslThreadGroup = authLookup.GetThreadGroup(path);

        if (dslThreadGroup != null) {

            return dslThreadGroup;
        } else {

        return threadGroup("GET " + path.replace("$", ""))
                .rampToAndHold(threadCount, "10", "3590")
                .children
                        (
                            onceOnlyController(AuthTokenSampler()),
                            runtimeController("600",
                            addEndpointSampler(method, path, count)),
                            AuthRefreshSampler()
                        );
                }

    }

    //Main test plan element

    public static DslTestPlan createTestPlan() throws IOException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        DslTestPlan tp;
        tp = testPlan(
                vars()
                        .set("Domain_Auth", "${__P(Host,sv2-aproxy-np2.anaplan-np.net)}")
                        .set("Password", "${__P(password,Welcome1)}")
                        .set("multiplexorHost", "${__P(multiplexorHost,rke-gproxy-np2.anaplan-np.net)}")
                        .set("protocol", "https")
                        .set("customerName", "${__P(customer,AuthTest)}"),
                httpCache(),
                csvDataSet("USERID-EMAIL_USER-GUID_ROLE-GUID_CUSTOMER-GUID.csv").delimiter(",").encoding("").variableNames("USERID-EMAIL,USER-GUID,ROLE-GUID,CUSTOMER-GUID"),
                csvDataSet("ROLES_USERID-EMAIL_USER-GUID_ROLE-GUID_CUSTOMER-GUID.csv").delimiter(",").encoding("").variableNames("RUSERID-EMAIL,RUSER-GUID,RROLE-GUID,RCUSTOMER-GUID"),
                httpCookies().disable(),
                setupThreadGroup("setUp Thread Group")
                        .children
                                (transaction("_#ignore Create Customer").generateParentSample(true)
                                .children
                                         (
                                            httpSampler("customer Search", "/1/0/customer/customers").host("${multiplexorHost}").port(9090).protocol("http").method("GET")
                                            .children
                                                (
                                                    httpHeaders().header("Content-Type", "application/json").header("Accept", "application/json"),
                                                    jsonExtractor("customerGuid", "$.customer[?(@.Name == \"AuthTest\")].CustomerGuid").defaultValue("notFound")
                                                )
                                         )
                                )
                               .children
                                (
                                    ifController("\"${customerGuid}\" == \"notFound\"")
                                    .children
                                            (
                                                httpSampler("Create Customer", "/1/0/customer/customers").host("${multiplexorHost}").port(9090).protocol("http").method("POST")
                                                .children
                                                    (
                                                        httpHeaders()
                                                        .header("Content-Type", "application/json")
                                                        .header("Accept", "application/json"),
                                                        jsonExtractor("customerGuid", "$.[*][?(@.Name==\"${customerName}\")].CustomerGuid").defaultValue("notFound")
                                                    )
                                                    .body(SetPostBody(commands, "create customer"))
                                            )
                                )

                                .children(transaction("_#ignore Create Workspace & MModel").generateParentSample(true)
                                        .children(httpSampler("_#ignore GET /1/0/workspaceserver/workspaceservers?searchCriteria=np2", "/1/0/workspaceserver/workspaceservers?searchCriteria=np2")
                                .host("${multiplexorHost}")
                                                .port(9090)
                                .protocol("http")
                                .method("GET").
                                        children(httpHeaders()
                                                        .header("Content-Type", "application/json")
                                                        .header("Accept", "application/json"),
                                                jsonExtractor("workspaceServerGuid  ", "$..WorkspaceServerGuid"),
                                                jsonExtractor("workspaceServerName  ", "$..Name")

                                        ))
                        .children(httpSampler("_#ignore /1/0/workspace/workspaces", "/1/0/workspace/workspaces")
                                .host("${multiplexorHost}")
                                .port(9090)
                                .protocol("http")
                                .method("POST").
                                        children(httpHeaders()
                                                        .header("Content-Type", "application/json")
                                                        .header("Accept", "application/json"),
                                                jsonExtractor("workspaceGuid", "$..WorkspaceGuid")


                                        ).body(SetPostBody(commands, "create workspace")))

                        .children(httpSampler("_#ignore /1/0/model/models", "/1/0/model/models")
                                .host("${multiplexorHost}")
                                .port(9090)
                                .protocol("http")
                                .method("POST").
                                        children(httpHeaders()
                                                        .header("Content-Type", "application/json")
                                                        .header("Accept", "application/json"),
                                                regexExtractor("modelGuid", "ModelGuid\":\"([a-zA-Z0-9]+)"),
                                                jsr223PostProcessor("FileWriter fstream = new FileWriter(\"NEWMODEL-GUID.csv\",true);\n" +
                                                        "fstream.write(vars.get(\"NEWMODEL-GUID\") + \"\\r\");\n" +
                                                        "fstream.close();")

                                        ).body(SetPostBody(commands, "create model")))
                        .children(jsr223Sampler("props.put(\"customerGuid\",vars.get(\"customerGuid\"));\n" +
                                "props.put(\"workspaceGuid\",vars.get(\"workspaceGuid\"));\n" +
                                "props.put(\"modelGuid\",vars.get(\"modelGuid\"));"))));


        return tp;
    }


    //Token generate sampler
    public static DslHttpSampler AuthTokenSampler()
    {
        return httpSampler("_#ignore /token/authenticate", "/token/authenticate")
                .host("${Domain_Auth}")
                .method("POST")
                .protocol("${protocol}")
                .children(
                        httpHeaders()
                                .header("Accept", "application/json")
                                .header("Authorization", "Basic ${loginBase64}"),
                        jsr223PreProcessor("import org.apache.commons.codec.binary.Base64;\n" +
                                "String loginb64= vars.get(\"USERID-EMAIL\")+\":\"+vars.get(\"Password\");\n" +
                                "byte[] encryptedlb64 = Base64.encodeBase64(loginb64.getBytes());\n" +
                                "vars.put(\"loginBase64\",new String(encryptedlb64));"),
                        regexExtractor("tokenValue", "tokenValue\":\"(.*)\",").template("$1$").matchNumber(1).defaultValue("NOTFOUND"));
    }

    //Token refresh sampler
    public static DslHttpSampler AuthRefreshSampler() {
        return httpSampler("_#ignore /token/refresh", "/token/refresh")
                .method("POST")
                .host("${Domain_Auth}")
                .protocol("${protocol}")
                .children
                        (
                        httpHeaders()
                                .header("Content-Type", "application/json")
                                .header("Authorization", "AnaplanAuthToken ${tokenValue}")
                                .header("Accept-Encoding", "gzip"),
                        regexExtractor("tokenValue", "tokenValue\":\"(.*)\",").template("$1$").matchNumber(1).defaultValue("NOTFOUND")
                        );
    }

    //Takes the traffic count from CSV as input and gives thread count as output
    public static String tpm(double count) {

        double tpm;
        String threadCount = "1";
        tpm = count / 60;

        if ((tpm) > 1) threadCount = "1";
        if ((tpm) > 10) threadCount = "5";
        if ((tpm) > 100) threadCount = "10";
        if ((tpm) > 1000) threadCount = "100";

        return threadCount;


    }

    public static int getCountFromCSV(String method, String url) throws IOException {

        CSVParser csvParser = new CSVParser(AuthService.class.getClassLoader().getResourceAsStream("AuthLoadProfile_Prod2Months-2023-03-01.csv"), true);
        csvParser.defineColumn("PATH", 2);
        csvParser.defineColumn("METHOD", 1);
        csvParser.defineColumn("COUNT", 3);
        String path;
        int cnt = 0;
        do {
            path = csvParser.get("PATH");
            //String method = csvParser.get("METHOD");
            int count = Integer.parseInt(csvParser.get("COUNT"));
            if (count >= countThreshold) {
                if (method.equalsIgnoreCase(method) && path.equalsIgnoreCase(url)) {
                    count = Integer.parseInt(csvParser.get("COUNT"));
                    cnt = count;

                }
            }
            csvParser.incrementRowIndex();
        } while (csvParser.hasRow());
        return cnt;
    }
}
