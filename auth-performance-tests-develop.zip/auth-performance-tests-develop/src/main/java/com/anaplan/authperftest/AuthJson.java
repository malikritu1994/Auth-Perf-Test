package com.anaplan.authperftest;

import jakarta.json.*;
import us.abstracta.jmeter.javadsl.core.threadgroups.DslThreadGroup;

import java.io.IOException;

import static com.anaplan.authperftest.AuthService.*;
import static us.abstracta.jmeter.javadsl.JmeterDsl.*;
import static us.abstracta.jmeter.javadsl.JmeterDsl.throughputTimer;

//API docs - reference for implementation
//https://anaplansite.atlassian.net/wiki/spaces/IN/pages/40305122/Authn+Service+API+docs#AuthnServiceAPIdocs-%2Faccesstoken%2Fauthenticate
//https://anaplansite.atlassian.net/wiki/spaces/IN/pages/619413779/Auth-Service+Authz+Service+API+docs

public class AuthJson  {

    public static DslThreadGroup Assert() throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        String path="/token/assert";
        double count = getCountFromCSV("POST",path);

        String threadCount= tpm(count);
         return threadGroup("POST "+ path.replace("$",""))
                .rampToAndHold(threadCount,"10","3590")
                .children(
                        vars()
                                .set("auth0Host","auth-dev2.auth0.anaplan-np.net")
                                .set("client_id","0OBHXXYdZvBND05owejhm7kcdvk0z3xq")
                                .set("client_secret","J3gObevnHicZI4duIHWl8lLBtlyJGQmuMZ3bRcQ61U4c4zDyAuqyE7kxv8IzxClE"),

                        csvDataSet("assert.csv")
                                .delimiter(",")
                                .encoding("")
                                .variableNames("assert-USERID-EMAIL,assert-Password,realm"),
                        onceOnlyController
                                (
                                httpSampler("_#ignore POST /oauth/token","/oauth/token")
                                        .host("${auth0Host}")
                                        .method("POST")
                                        .protocol("${protocol}")
                                        .body("{ \"client_id\": \"${client_id}\", \"client_secret\": \"${client_secret}\", \"audience\": \"https://auth-service.anaplan.com\", \"grant_type\": \"client_credentials\" }")
                                        .children(
                                                httpHeaders().header("Content-Type","application/json"),
                                                throughputTimer(1.0),
                                                regexExtractor("client_access_token","access_token\":\"([^\"]+)\"").template("$1$").matchNumber(1).defaultValue("NOTFOUND")
                                                ),
                                httpSampler("_#ignore POST /oauth/token","/oauth/token")
                                        .host("${auth0Host}")
                                        .method("POST")
                                        .protocol("${protocol}")
                                        .body("{ \"client_id\": \"${client_id}\", \"client_secret\": \"${client_secret}\", \"grant_type\": \"http://auth0.com/oauth/grant-type/password-realm\", \"username\": \"${auth0User}\", \"password\": \"${auth0Password}\", \"realm\": \"${realm}\", \"scope\": \"id_token openid email profile\" }")
                                        .children
                                                (
                                                httpHeaders().header("Content-Type","application/json"),
                                                throughputTimer(1.0),
                                                regexExtractor("user_id_token","id_token\":\"([^\"]+)\"").template("$1$").matchNumber(1).defaultValue("NOTFOUND"),
                                                jsr223PreProcessor("props.put(\"auth0Password\",vars.get(\"${assert-Password}\"));\n" +
                                                        "props.put(\"auth0User\",vars.get(\"${assert-USERID-EMAIL}\"));\n"+
                                                        "props.put(\"realm\",vars.get(\"${realm}\"));")
                                                )
                                ),

                        runtimeController("36000")
                                .children(

                                        httpSampler("POST"+" "+path.replace("$",""),path)
                                                .host("${Domain_Auth}")
                                                .protocol("${protocol}")
                                                .method("POST").
                                                children(httpHeaders()
                                                                .header("X-AAT","BEARER ${client_access_token}")
                                                                .header("X-AIT","${user_id_token}")
                                                                .header("Content-Type","application/json"),

                                                        throughputTimer(count/60))
                                                .body(SetPostBody(commands,path)))

                );



    }


    public static DslThreadGroup Authenticate(String path) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
       // String path="/token/authenticate";
        int count = getCountFromCSV("POST",path);

        String threadCount= tpm(count);
        return threadGroup("POST " + path.replace("$", ""))
                .rampToAndHold(threadCount, "10", "3590")
                .children(

                        httpSampler("POST " + path.replace("$", ""), path)
                                .host("${Domain_Auth}")
                                .protocol("${protocol}")
                                .method("POST").
                                children(httpHeaders()
                                                .header("Content-Type", "application/json")
                                                .header("Accept-Encoding", "gzip")
                                                .header("Authorization", "Basic ${__base64Encode(${USERID-EMAIL}:${Password})}")
                                                .header("User-Agent", "AuthPerfTest_POST" + path.replace("$", "").replace(" ", "")),

                                        throughputTimer(count / 60))


                );



    }

    public static DslThreadGroup cookie(String path) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        int count = getCountFromCSV("GET",path);

        String threadCount= tpm(count);
        return threadGroup("GET " + path.replace("$", ""))
                .rampToAndHold(threadCount, "10", "3590")
                .children(
                        onceOnlyController(AuthTokenSampler()),
                        runtimeController("600",httpSampler("GET" + " " + path.replace("$", ""), path)
                                .host("${Domain_Auth}")
                                .protocol("${protocol}")
                                .method("GET").
                                        children(httpHeaders()
                                                .header("Content-Type", "application/json")
                                                .header("Accept-Encoding", "gzip")
                                                .header("Authorization", "AnaplanAuthToken ${tokenValue}")
                                                .header("User-Agent", "AuthPerfTest_" + "GET" + path.replace("$", "").replace(" ", ""))
                                                .header("Cookie","att=${tokenValue}"),
                                                throughputTimer(count / 60))
                                                .body(SetPostBody(commands, path))),
                                AuthRefreshSampler()
                        );

    }




    public static DslThreadGroup logOut(String path) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        int count = getCountFromCSV("POST",path);
        String threadCount= tpm(count);


        return threadGroup("POST " + path.replace("$", ""))
                .rampToAndHold(threadCount, "10", "3590")
                .children(
                        csvDataSet("LOGOUT-USER.csv")

                                .delimiter(",")
                                .encoding("")
                                .variableNames("LOGOUT-USER"),
                        httpSampler("POST /token/authenticate", "token/authenticate")
                                .host("${Domain_Auth}")
                                .protocol("${protocol}")
                                .method("POST").
                                children(httpHeaders()
                                                .header("Content-Type", "application/json")
                                                .header("Accept-Encoding", "gzip")
                                                .header("Authorization", "Basic ${__base64Encode(${LOGOUT-USER}:${Password})}")
                                                .header("User-Agent", "AuthPerfTest_POST" + path.replace("$", "").replace(" ", "")),

                                        regexExtractor("tokenValue", "tokenValue\":\"(.*)\",")
                                                .template("$1$")
                                                .matchNumber(1))
                        ,

                        addEndpointSampler("POST", path, count)
                );



    }

    public static JsonObject createCustomerJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("Name", "${customerName}")
                .add("Note","Test new")
                .add("Type","internal")
                .add("SystemOwnedFlag",false)
                .add("DateCreated","2022-04-30T12:10:20.000-08:00")
                .add("AppInstallEnabled",true)
                .add("PasswordExpiryType","NEVER")
                .add("CasSessionTimeout",3600)
                .build ();
        return obj;

    }

    public static JsonObject createWorkspaceJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("Name", "PerfAuth_${__UUID}")
                .add("Active",true)
                .add("CurrentWorkspaceServerGuid","${workspaceServerGuid}")
                .add("LastModified","2016-04-26T13:09:03.000-07:00")
                .add("Server","${workspaceServerName}")
                .add("CustomerOwned",false)
                .add("PartnerOperated",false)
                .add("AppInstallEnabled",true)
                .add("SizeLimit",1000000000)
                .add("SizeAllowance",1073741824)
                .add("CurrentCustomerGuid","${customerGuid}")
                .add("MemoryUsage",0)
                .build ();
        return obj;

    }

    public static JsonObject createModelJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("ModelGuid", "${__RandomString(32,ABCDEF0123456789,NEWMODEL-GUID)}")
                .add("Name","${NEWMODEL-GUID}-AuthTEST")
                .add("ActiveState","UNLOCKED")
                .add("CalculationPolicy","DEFAULT")
                .add("DisplayOrder",1)
                .add("ISOCreationDate","2015-05-04T17:56:16.000Z")
                .add("LastModifiedByUserGuid","${USER-GUID}")
                .add("CurrentWorkspaceGuid","${workspaceGuid}")
                .add("CurrentWorkspaceName","")
                .add("categoryValues","[]")
                .add("customerGuid","${customerGuid}")
                .build ();
        return obj;

    }


    public static JsonObject accessTokenAuthenticateJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("channel", "inappNotif")
                .add ("recipients", Json.createArrayBuilder ()
                        .add (Json.createObjectBuilder ()
                                .add ("userGuid", "${userGuid}")
                                .add ("userEmail", "${Username}")
                        ))
                .add ("messagePayload", Json.createObjectBuilder ()
                        .add ("url", "something.com")
                        .add ("title", "Notification title")
                        .add ("description", "Notification detail")
                        .add ("notificationType", "info")
                )

                .build ();
        return obj;

    }

    public static JsonObject v1AuthorizeJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("authorizeRequests", Json.createArrayBuilder ()

                        .add (Json.createObjectBuilder ()
                                .add ("index",1)
                                .add ("resourceType","TENANT")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",2)
                                .add("instanceId","${__P(customerGuid)}")
                                .add ("resourceType","TENANT")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",3)
                                .add("instanceId","${__P(customerGuid)}")
                                .add ("resourceType","TENANT")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",4)
                                .add("instanceId","${__P(customerGuid)}")
                                .add ("resourceType","TENANT")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",5)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","MEMBERSHIP")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",6)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","MEMBERSHIP")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",7)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","MEMBERSHIP")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",8)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","MEMBERSHIP")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",9)
                                .add ("resourceType","MODEL")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",10)
                                .add ("resourceType","MODEL")
                                .add("instanceId","${__P(modelGuid)}")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",11)
                                .add ("resourceType","MODEL")
                                .add("instanceId","${__P(modelGuid)}")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",12)
                                .add ("resourceType","MODEL")
                                .add("instanceId","${__P(modelGuid)}")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",13)
                                .add ("resourceType","POLICY")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",14)
                                .add ("resourceType","POLICY")
                                .add("instanceId","8383662140476651635")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",15)
                                .add ("resourceType","POLICY")
                                .add("instanceId","8383662140476651635")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",16)
                                .add ("resourceType","POLICY")
                                .add("instanceId","8383662140476651635")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",17)
                                .add ("resourceType","ROLE")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",18)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","ROLE")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",19)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","ROLE")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",20)
                                .add("instanceId","8383662140476651634")
                                .add ("resourceType","ROLE")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",21)
                                .add ("resourceType","HOST")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",22)
                                .add("instanceId","${__P(hostGuid)}")
                                .add ("resourceType","HOST")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",23)
                                .add("instanceId","${__P(hostGuid)}")
                                .add ("resourceType","HOST")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",24)
                                .add("instanceId","${__P(hostGuid)}")
                                .add ("resourceType","HOST")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",25)
                                .add ("resourceType","USER")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",26)
                                .add ("resourceType","USER")
                                .add("instanceId","${USER-GUID}")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",27)
                                .add ("resourceType","USER")
                                .add("instanceId","${USER-GUID}")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",28)
                                .add ("resourceType","USER")
                                .add("instanceId","${USER-GUID}")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",29)
                                .add ("resourceType","WORKSPACE")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",30)
                                .add ("resourceType","WORKSPACE")
                                .add("instanceId","${__P(workspaceGuid)}")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",31)
                                .add ("resourceType","WORKSPACE")
                                .add("instanceId","${__P(workspaceGuid)}")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",32)
                                .add ("resourceType","WORKSPACE")
                                .add("instanceId","${__P(workspaceGuid)}")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",33)
                                .add ("resourceType","POOL")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",34)
                                .add ("resourceType","POOL")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",35)
                                .add ("resourceType","POOL")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",36)
                                .add ("resourceType","POOL")
                                .add ("operation","DELETE"))


                )

                .build ();
        return obj;

    }

    public static JsonObject v2AuthorizeJson () {

        JsonObject obj = Json.createObjectBuilder ()
                .add ("authorizeRequests", Json.createArrayBuilder ()

                .add (Json.createObjectBuilder ()
                .add ("index",1)
                .add ("resourceType","MODEL")
                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                .add ("index",2)
                .add ("resourceType","CUSTOMER")
                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",3)
                                .add ("resourceType","WORKSPACE")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",4)
                                .add ("resourceType","MODEL")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",5)
                                .add ("resourceType","USER")
                                .add ("operation","READ"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",6)
                                .add ("resourceType","USER")
                                .add ("operation","UPDATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",7)
                                .add ("resourceType","MEMBERSHIP")
                                .add ("operation","CREATE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",8)
                                .add ("resourceType","CUSTOMER")
                                .add ("operation","DELETE"))
                        .add (Json.createObjectBuilder ()
                                .add ("index",9)
                                .add ("resourceType","CUSTOMER")
                                .add ("operation","CREATE")))

                .build ();
        return obj;

    }

}




