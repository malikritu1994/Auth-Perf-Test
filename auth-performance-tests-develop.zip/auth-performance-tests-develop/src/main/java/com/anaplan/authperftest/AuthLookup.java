package com.anaplan.authperftest;
import com.fasterxml.jackson.core.JsonProcessingException;
import us.abstracta.jmeter.javadsl.core.threadgroups.DslThreadGroup;

import java.io.IOException;
import java.util.*;

public class AuthLookup {
    HashMap <String, DslThreadGroup> commands;

    public AuthLookup() throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException {

        commands = new HashMap< String, DslThreadGroup>();
        commands.put("/token/assert", AuthJson.Assert());
        commands.put("/token/authenticate", AuthJson.Authenticate("/token/authenticate"));
        commands.put("/token/authenticate?Authorization=Basic%20encoded_username%3Apassword", AuthJson.Authenticate("/token/authenticate?Authorization=Basic%20encoded_username%3Apassword"));
        commands.put("/token/authenticate?Authorization=Basic+encoded_username%3Apassword", AuthJson.Authenticate("/token/authenticate?Authorization=Basic+encoded_username%3Apassword"));
        commands.put("/token/logout", AuthJson.logOut("/token/logout"));
        commands.put("/api/1/cookie/validate", AuthJson.cookie("/api/1/cookie/validate"));

    }

    public static Map jsonLookup () {

        HashMap commands = new HashMap< String, Object>();

        // Populate commands map
        commands.put ("/accesstoken/authenticate?connectionMethod=Basic", AuthJson.accessTokenAuthenticateJson ());
        commands.put ("/api/1/2/authorize", AuthJson.v2AuthorizeJson ());
        commands.put("/api/1/authorize",AuthJson.v1AuthorizeJson ());
        commands.put("create customer",AuthJson.createCustomerJson());
        commands.put("create workspace",AuthJson.createWorkspaceJson());
        commands.put("create model",AuthJson.createModelJson());


        return commands;
    }


    public DslThreadGroup GetThreadGroup(String key){
        if (this.commands.containsKey(key)) {
            return this.commands.get(key);
        }

        return null;

    }

    public static String GetJsonString (Map map, String key){
        if (map.containsKey(key)) {
            return map.get(key).toString ();
        }
        else{

            System.out.println ("Post body undefined for uri "+key);
            return "";
        }


    }
}
