Auth service performance tests using Jmeter DSL

It generates Jmeter JMX test plan using Jmeter DSL

There are three java files which do the work - AuthService.java AuthLook.java and AuthJson.java

The input to this project would be the load profile in csv format from splunk (or grafana in future) which is in the resources folder 
